from pathlib import Path
p=Path('/mnt/data/xena_security/index.html')
s=p.read_text()
s=s.replace('<a href="#story">About <sup>03</sup></a>','<a href="#story">About <sup>03</sup></a>\n      <a href="#security">Security <sup>04</sup></a>')
section='''
    <section class="security-section shell" id="security">
      <div class="section-heading">
        <div><p class="eyebrow">04 / SECURITY DESK</p><h2>Watch the<br><em>front door.</em></h2></div>
        <p class="heading-aside">Ringkasan keamanan untuk memantau percobaan mencurigakan, mengelola daftar blokir, dan mencatat insiden. Data pada demo ini tersimpan di browser, bukan firewall server.</p>
      </div>
      <div class="security-topline"><span class="security-live"><i></i> LOCAL SECURITY CONSOLE</span><span id="securityUpdated">DEMO MODE · BROWSER STORAGE</span></div>
      <div class="security-metrics">
        <article><span>PERCOBAAN TERCATAT</span><strong id="attemptCount">3</strong><small>Event contoh pada log</small></article>
        <article><span>IP DALAM DAFTAR BLOKIR</span><strong id="blockedCount">2</strong><small>Aturan lokal di browser ini</small></article>
        <article><span>STATUS KONSOL</span><strong class="metric-status">MONITORING</strong><small>Bukan proteksi jaringan aktif</small></article>
      </div>
      <div class="security-grid">
        <article class="security-panel">
          <div class="security-panel-head"><div><p class="eyebrow">ACCESS CONTROL / 01</p><h3>IP blocklist</h3></div><span class="panel-count" id="blocklistLabel">02 ENTRIES</span></div>
          <form id="blockIpForm" class="block-ip-form">
            <label for="blockIpInput">Tambahkan alamat IPv4</label>
            <div class="block-ip-controls"><input id="blockIpInput" name="ip" type="text" inputmode="decimal" placeholder="Contoh: 203.0.113.10" autocomplete="off" required><button type="submit">Tambah IP <span>＋</span></button></div>
            <small>Masukkan IP yang memang kamu kelola dan punya alasan untuk diblokir. Contoh alamat dokumentasi tidak merujuk ke pengguna nyata.</small>
          </form>
          <div class="table-wrap"><table class="security-table"><thead><tr><th>IP ADDRESS</th><th>ALASAN</th><th>AKSI</th></tr></thead><tbody id="blocklistRows"></tbody></table></div>
          <p class="security-empty" id="blocklistEmpty" hidden>Belum ada IP yang diblokir.</p>
        </article>
        <article class="security-panel event-panel">
          <div class="security-panel-head"><div><p class="eyebrow">TRAFFIC WATCH / 02</p><h3>Percobaan mencurigakan</h3></div><span class="panel-count">SAMPLE LOG</span></div>
          <div class="event-list" id="securityEvents">
            <div class="security-event"><span class="event-mark event-warn">!</span><div><strong>Request rate tidak wajar</strong><small>192.0.2.24 · HTTP burst · contoh</small></div><time>14:32:08</time></div>
            <div class="security-event"><span class="event-mark event-block">×</span><div><strong>IP masuk blocklist lokal</strong><small>198.51.100.17 · manual block · contoh</small></div><time>14:28:41</time></div>
            <div class="security-event"><span class="event-mark event-warn">!</span><div><strong>Lonjakan request simulasi</strong><small>203.0.113.8 · rate threshold · contoh</small></div><time>14:17:03</time></div>
          </div>
          <button class="security-secondary" id="addDemoEvent" type="button">＋ Catat simulasi percobaan</button>
          <p class="security-disclaimer">Log di atas adalah data contoh/simulasi untuk tampilan dashboard. Website statis ini tidak memantau trafik asli dan tidak menjalankan serangan.</p>
        </article>
      </div>
      <div class="security-footnote"><svg class="ui-icon"><use href="#i-shield-check"/></svg><p><strong>Perlindungan DDoS sungguhan perlu dipasang di sisi infrastruktur.</strong> Hubungkan domain ke layanan CDN/WAF (misalnya Cloudflare), aktifkan proteksi DDoS dan rate limiting, lalu gunakan firewall di server/origin. Daftar blokir di halaman ini hanya demonstrasi lokal sampai dihubungkan ke backend yang aman.</p></div>
    </section>
'''
s=s.replace('    <section class="contact-section">',section+'\n    <section class="contact-section">')
p.write_text(s)
