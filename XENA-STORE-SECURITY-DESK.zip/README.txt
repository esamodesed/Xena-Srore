XENA STORE — VISUAL REFRESH + SECURITY DESK

Isi ZIP:
- index.html, style.css, script.js: website statis siap di-host.
- assets/*.svg dan assets/revenant-reference.jpg: aset katalog.
- Security Desk: dashboard demo untuk melihat contoh event, menambah IP ke daftar blokir lokal, dan menghapusnya.

PENTING — BATAS FITUR KEAMANAN:
Security Desk pada versi ini hanya UI demo sisi browser. Daftar IP disimpan di localStorage browser admin dan tidak memblokir trafik jaringan/server. Event percobaan DDoS adalah contoh/simulasi, bukan deteksi trafik asli. Jangan menampilkan data demo sebagai insiden nyata.

Untuk proteksi DDoS sungguhan:
1. Letakkan domain di belakang CDN/WAF seperti Cloudflare dan aktifkan proteksi DDoS.
2. Atur rate limiting/challenge pada endpoint yang relevan.
3. Batasi akses origin agar hanya menerima trafik dari proxy/CDN tepercaya.
4. Gunakan firewall server/provider untuk aturan allow/deny.
5. Untuk blocklist dan event nyata, buat backend admin terautentikasi yang memvalidasi input, menyimpan audit log, dan menerapkan aturan ke firewall/provider API. Jangan menaruh API token di JavaScript frontend.

Cara pakai:
Upload semua isi ZIP ke root hosting (index.html harus langsung ada di root).
