(() => {
  'use strict';
  const WA_NUMBER = '62883130548406';
  const navToggle = document.getElementById('navToggle');
  const mainNav = document.getElementById('mainNav');

  // Branded loading state: shimmer only while the page is being prepared.
  const loader = document.getElementById('pageLoader');
  window.addEventListener('load', () => {
    window.setTimeout(() => {
      loader?.classList.add('loader-done');
      document.body.classList.add('page-ready');
      window.setTimeout(() => loader?.remove(), 550);
    }, 520);
  });

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
    mainNav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
      mainNav.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    }));
  }

  const openWhatsApp = (message) => {
    const url = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Tactile press feedback for every actionable control.
  document.querySelectorAll('button, .button, .product-action, .contact-card, .nav-contact').forEach((control) => {
    control.addEventListener('pointerdown', () => control.classList.add('is-pressed'));
    ['pointerup', 'pointercancel', 'pointerleave'].forEach((eventName) => {
      control.addEventListener(eventName, () => control.classList.remove('is-pressed'));
    });
  });

  document.querySelectorAll('[data-product]').forEach((button) => {
    button.addEventListener('click', () => {
      const product = button.dataset.product || 'Produk Xena Store';
      button.classList.add('is-confirmed');
      openWhatsApp(`Halo Xena Store, saya mau tanya tentang ${product}. Mohon info stok, detail, dan total harga setelah promo jika tersedia.`);
      window.setTimeout(() => button.classList.remove('is-confirmed'), 450);
    });
  });

  const filterButtons = document.querySelectorAll('[data-filter]');
  const productCards = document.querySelectorAll('#productGrid .product-card');
  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;
      filterButtons.forEach((item) => {
        const active = item === button;
        item.classList.toggle('active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      productCards.forEach((card, index) => {
        const show = filter === 'all' || card.dataset.kind === filter;
        card.classList.toggle('is-hidden', !show);
        if (show) {
          card.classList.remove('card-enter');
          requestAnimationFrame(() => card.classList.add('card-enter'));
        }
      });
    });
  });

  // VPS package cards feed the same request form.
  const planSelect = document.getElementById('vpsPlan');
  const routeType = document.getElementById('routeType');
  document.querySelectorAll('[data-vps-plan]').forEach((button) => {
    button.addEventListener('click', () => {
      if (planSelect) planSelect.value = button.dataset.vpsPlan;
      document.getElementById('vps-config')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      updateSummary();
    });
  });

  const country = document.getElementById('country');
  const panel = document.getElementById('panel');
  const usecase = document.getElementById('usecase');
  const summary = document.getElementById('configSummary');
  const updateSummary = () => {
    if (!country || !panel || !summary) return;
    const plan = planSelect?.value || 'Belum memilih paket';
    const route = routeType?.value || 'VPS legal / resmi';
    summary.textContent = `${route} · ${plan} · ${country.value} · ${panel.value}`;
  };
  [country, panel, usecase, planSelect, routeType].forEach((field) => field?.addEventListener('change', updateSummary));
  updateSummary();

  const vpsForm = document.getElementById('vpsForm');
  vpsForm?.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!country || !panel || !usecase) return;
    const message = [
      'Halo Xena Store, saya mau tanya VPS.',
      `Jalur layanan: ${routeType?.value || 'VPS legal / resmi'}`,
      `Jenis/paket: ${planSelect?.value || 'Mohon rekomendasi'}`,
      `Lokasi server: ${country.value}`,
      `Panel: ${panel.value}`,
      `Kebutuhan: ${usecase.value}`,
      'Mohon info harga, spesifikasi lengkap, ketersediaan, ketentuan free install panel, dan detail garansi.'
    ].join('\n');
    openWhatsApp(message);
  });
})();

// Local security-console demo. This UI does not enforce firewall rules.
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const storageKey = 'xena-security-blocklist-v1';
  const seed = [
    { ip: '192.0.2.24', reason: 'Contoh / rate alert' },
    { ip: '198.51.100.17', reason: 'Contoh / manual block' }
  ];
  let blocked = seed;
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
    if (Array.isArray(saved)) blocked = saved;
  } catch (_) {}

  const validIPv4 = (value) => {
    const parts = value.trim().split('.');
    return parts.length === 4 && parts.every((part) => /^\d{1,3}$/.test(part) && Number(part) >= 0 && Number(part) <= 255);
  };
  const persist = () => {
    try { localStorage.setItem(storageKey, JSON.stringify(blocked)); } catch (_) {}
  };
  const render = () => {
    const tbody = $('blocklistRows');
    if (!tbody) return;
    tbody.replaceChildren();
    blocked.forEach((entry, index) => {
      const tr = document.createElement('tr');
      const ip = document.createElement('td'); ip.textContent = entry.ip;
      const reason = document.createElement('td'); reason.textContent = entry.reason || 'Manual block';
      const action = document.createElement('td');
      const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Unblock';
      button.setAttribute('aria-label', `Hapus ${entry.ip} dari daftar blokir lokal`);
      button.addEventListener('click', () => {
        blocked.splice(index, 1); persist(); render();
      });
      action.append(button); tr.append(ip, reason, action); tbody.append(tr);
    });
    $('blockedCount').textContent = String(blocked.length);
    $('blocklistLabel').textContent = `${String(blocked.length).padStart(2, '0')} ENTRIES`;
    $('blocklistEmpty').hidden = blocked.length !== 0;
  };
  const form = $('blockIpForm');
  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    const input = $('blockIpInput');
    const ip = input.value.trim();
    if (!validIPv4(ip)) { input.setCustomValidity('Masukkan alamat IPv4 yang valid.'); input.reportValidity(); return; }
    input.setCustomValidity('');
    if (blocked.some((entry) => entry.ip === ip)) { input.setCustomValidity('IP ini sudah ada di daftar lokal.'); input.reportValidity(); return; }
    blocked.unshift({ ip, reason: 'Manual block / lokal' });
    persist(); render(); input.value = '';
  });
  $('blockIpInput')?.addEventListener('input', (event) => event.currentTarget.setCustomValidity(''));
  $('addDemoEvent')?.addEventListener('click', () => {
    const list = $('securityEvents');
    const row = document.createElement('div'); row.className = 'security-event security-row-enter';
    const mark = document.createElement('span'); mark.className = 'event-mark event-warn'; mark.textContent = '!';
    const detail = document.createElement('div');
    const title = document.createElement('strong'); title.textContent = 'Percobaan request simulasi dicatat';
    const sub = document.createElement('small'); sub.textContent = '198.51.100.42 · demo event · bukan trafik nyata';
    const time = document.createElement('time'); time.textContent = new Date().toLocaleTimeString('id-ID', { hour12: false });
    detail.append(title, sub); row.append(mark, detail, time); list.prepend(row);
    $('attemptCount').textContent = String(Number($('attemptCount').textContent || 0) + 1);
    $('securityUpdated').textContent = `UPDATED ${time.textContent} · DEMO MODE`;
  });
  render();
})();
